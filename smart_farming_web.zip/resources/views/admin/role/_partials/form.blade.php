@component('admin._components.general-input')
    @slot('field', 'role')
    @slot('label', 'Nama Role')
    @slot('required', true)
    @slot('placeholder', 'Masukkan nama role')
@endcomponent

# smart_farming_web
Smart Farming Web App

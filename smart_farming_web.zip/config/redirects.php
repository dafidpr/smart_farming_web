<?php
return [    
    'redirectIfAuth' => '/administrator/dashboard',
    'redirectIfUnAuth' => '/'
];
<div class="form-group">
    <?php if(isset($label)): ?>
        <label class="form-label" for="<?php echo e($id ?? $field); ?>"><?php echo e($label); ?> <?php if(isset($required) && $required): ?> <span class="text-danger">*</span> <?php endif; ?></label>
    <?php endif; ?>
    <div class="form-control-wrap">
        <?php if(isset($icon)): ?>
            <div class="form-icon form-icon-left">
                <em class="<?php echo e($icon); ?>"></em>
            </div>
        <?php endif; ?>
        <?php if(isset($type) && $type == 'file'): ?>
            <div class="custom-file">
                <input type="file" class="custom-file-input" name="<?php echo e($field); ?>" id="<?php echo e($id ?? $field); ?>" placeholder="<?php echo e($placeholder ?? ''); ?>" autocomplete="off">
                <label class="custom-file-label"  for="">Choose file</label>
            </div>
        <?php else: ?>
            <input type="<?php echo e($type ?? 'text'); ?>" class="form-control form-control-lg <?php echo e($classes ?? ''); ?>" name="<?php echo e($field); ?>" data-date-format="<?php echo e($dateFormat ?? ''); ?>" id="<?php echo e($id ?? $field); ?>" placeholder="<?php echo e($placeholder ?? ''); ?>" autocomplete="off">
        <?php endif; ?>
        
    </div>
    <i class="text-danger small d-none" id="<?php echo e($field); ?>-error"></i>
</div>
<?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/_components/general-input.blade.php ENDPATH**/ ?>
<?php echo $__env->yieldContent('content'); ?>

<script>
    document.title = "<?php echo e($title .' | '. getSetting('web_name')); ?>";

    if(!window.jQuery){
        document.body.innerHTML = "";
        window.location.reload();
    }
</script>

<!-- JS Dynamic Dependencies -->
<?php echo $__env->yieldPushContent('script'); ?>

<?php if(isset($mod)): ?>
<!--Script Custom-->
<script src="<?php echo e(asset('admin/mod/' . $mod . '.js')); ?>"></script>
<?php endif; ?>
<script src="<?php echo e(asset('admin/mod/mod_main.js')); ?>"></script>

<?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/layouts/ajax.blade.php ENDPATH**/ ?>
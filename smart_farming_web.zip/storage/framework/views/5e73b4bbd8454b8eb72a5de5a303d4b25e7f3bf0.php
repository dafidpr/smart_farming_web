<div class="modal fade" tabindex="-1" role="dialog" id="<?php echo e($id); ?>">
    <div class="modal-dialog modal-dialog-top" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <?php if(isset($form)): ?>
                <?php echo $form; ?>

                <?php echo csrf_field(); ?>
            <?php endif; ?>
            <div class="modal-body modal-body-lg">
                <h5 class="title"><?php echo e($title ?? 'Untitled Modal'); ?></h5>
                <div class="tab-content">
                    <div class="tab-pane active">
                        <form action="" method="post" id="formSubmit">
                            <div class="row gy-4">
                                <div class="col-md-12">
                                    <?php echo $slot; ?>

                                </div>
                                <?php if(!isset($withoutFooter) || !$withoutFooter): ?>
                                    <div class="col-12">
                                        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                            <?php if(!isset($withoutSubmit) || !$withoutSubmit): ?>
                                                <?php echo $submitBt ?? '<li><button type="submit" class="btn btn-primary"><em class="icon ni ni-send"></em><span> Simpan </span> </button></li>'; ?>

                                            <?php endif; ?>
                                            <li>
                                                <a href="#" data-dismiss="modal" class="link link-light"><?php echo e($closeButtonText ?? 'Tutup'); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div><!-- .tab-pane -->
                </div>
            </div><!-- .modal-body -->
            <?php echo isset($form) ? '</form>' : ''; ?>

        </div><!-- .modal-content -->
    </div><!-- .modal-dialog -->
</div><!-- .modal -->
<?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/_components/modal.blade.php ENDPATH**/ ?>
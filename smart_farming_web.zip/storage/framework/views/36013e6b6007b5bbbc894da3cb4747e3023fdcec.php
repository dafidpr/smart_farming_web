

<?php $__env->startSection('child'); ?>
<div class="nk-app-root">
    <!-- main @s  -->
    <div class="nk-main ">
        <!-- wrap @s  -->
        <div class="nk-wrap nk-wrap-nosidebar">
            <!-- content @s  -->
            <div class="nk-content ">
               <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- wrap @e  -->
        </div>
        <!-- content @e  -->
    </div>
    <!-- main @e  -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/assets/assets/js/bundle.js?ver=2.2.0')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/assets/js/scripts.js?ver=2.2.0')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/assets/js/example-sweetalert.js?ver=2.2.0')); ?>"></script>
<script src="<?php echo e(asset('admin/mod/mod_auth.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/layouts/auth.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>

<div class="nk-content-body">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><?php echo e($title); ?></h3>
                <div class="nk-block-des text-soft">
                    <p>Anda memiliki total <?php echo e($devices->count()); ?> perangkat.</p>
                </div>
            </div><!-- .nk-block-head-content -->
            <div class="nk-block-head-content">
                <div class="toggle-wrap nk-block-tools-toggle">
                    <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                    <div class="toggle-expand-content" data-content="pageMenu">
                        <ul class="nk-block-tools g-3">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-devices')): ?> 
                                <li><a href="#myModal" data-toggle="modal" class="btn btn-light bg-white add add-role"><em class="icon ni ni-plus"></em><span>Tambah Perangkat Baru</span></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div><!-- .toggle-wrap -->
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->
    <div class="nk-block">
        <div class="card card-bordered card-preview">
            <div class="card-inner-group">
                <div class="card-inner position-relative card-tools-toggle">
                    <div class="card-title-group">
                        <div class="card-tools">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-devices')): ?>    
                                <div class="form-inline flex-nowrap gx-3">
                                    <div class="form-wrap w-150px">
                                        <select class="form-select form-select-sm" name="action" data-search="off" data-placeholder="Bulk Action">
                                            <option value="">Bulk Action</option>
                                            <option value="delete">Delete</option>
                                        </select>
                                    </div>
                                    <div class="btn-wrap">
                                        <span class="d-none d-md-block"><button class="btn btn-dim btn-outline-light bulk-action" data-url="/administrator/devices/multipleDelete">Apply</button></span>
                                        <span class="d-md-none"><button class="btn btn-dim btn-outline-light btn-icon bulk-action" data-url="/administrator/devices/multipleDelete"><em class="icon ni ni-arrow-right"></em></button></span>
                                    </div>
                                </div><!-- .form-inline -->
                            <?php endif; ?>
                        </div><!-- .card-tools -->
                    </div><!-- .card-title-group -->
                </div><!-- .card-inner -->
                <div class="card-inner p-4">
                    <table class="datatable-init nk-tb-list nk-tb-ulist" data-auto-responsive="false" id="">
                        <thead class="nk-tb-head bg-light-table">
                            <tr class="nk-tb-item">
                                <th class="nk-tb-col nk-tb-col-check">
                                    <div class="custom-control custom-control-sm custom-checkbox notext">
                                        <input type="checkbox" class="custom-control-input" id="uid">
                                        <label class="custom-control-label" for="uid"></label>
                                    </div>
                                </th>
                                <th class="nk-tb-col"><span class="sub-text">Nama Perangkat</span></th>
                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Serial Number</span></th>
                                <th class="nk-tb-col tb-col-mb"><span class="sub-text">Status</span></th>
                                <th class="nk-tb-col nk-tb-col-tools text-right"></th>
                            </tr>
                        </thead><!-- .nk-tb-item -->
                        <tbody>
                            <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="nk-tb-item">
                                <td class="nk-tb-col nk-tb-col-check">
                                    <div class="custom-control custom-control-sm custom-checkbox notext">
                                        <input type="checkbox" class="custom-control-input uid deleteItems" value="<?php echo e($item->id); ?>" id="uid<?php echo e($loop->iteration); ?>">
                                        <label class="custom-control-label" for="uid<?php echo e($loop->iteration); ?>"></label>
                                    </div>
                                </td>
                                <td class="nk-tb-col tb-col-mb">
                                    <span><?php echo e($item->name); ?></span>
                                </td>
                                <td class="nk-tb-col tb-col-mb">
                                    <span><?php echo e($item->serial_number); ?></span>
                                </td>
                                <td class="nk-tb-col tb-col-md">
                                    <span class="badge badge-dot badge-<?php echo e($item->is_used == 'Y' ? 'warning' : 'success'); ?>"><?php echo e($item->is_used == 'Y' ? 'Telah Digunakan' : 'Belum Digunakan'); ?></span>
                                </td>
                                <td class="nk-tb-col nk-tb-col-tools">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update-roles','delete-roles'])): ?>
                                        <ul class="nk-tb-actions gx-1">
                                            <li>
                                                <div class="drodown">
                                                    <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <ul class="link-list-opt no-bdr">
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-devices')): ?>
                                                                <li><a href="#myModal" data-toggle="modal" data-id="<?php echo e(Hashids::encode($item->id)); ?>" class="edit"><em class="icon ni ni-edit"></em><span>Edit Device</span></a></li> 
                                                            <?php endif; ?>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-devices')): ?>
                                                                <li><a class="deleteItem" href="/administrator/devices/<?php echo e(Hashids::encode($item->id)); ?>/delete"><em class="icon ni ni-trash"></em><span>Delete Device</span></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    <?php endif; ?>
                                </td>
                            </tr><!-- .nk-tb-item -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table><!-- .nk-tb-list -->
                </div><!-- .card-inner -->
            </div><!-- .card-inner-group -->
        </div><!-- .card -->
    </div><!-- .nk-block -->
</div>
<?php $__env->startComponent('admin._components.modal'); ?>
    <?php $__env->slot('id', 'myModal'); ?>
    <?php $__env->slot('title', 'Tambah Perangkat Baru'); ?>
    <?php $__env->slot('form'); ?>
        <form action="" method="POST" id="formSubmit">
    <?php $__env->endSlot(); ?>
    <?php echo $__env->make('admin.device._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if (isset($__componentOriginal684e58f871c48d14dad4cc2ac7d013dc237c2333)): ?>
<?php $component = $__componentOriginal684e58f871c48d14dad4cc2ac7d013dc237c2333; ?>
<?php unset($__componentOriginal684e58f871c48d14dad4cc2ac7d013dc237c2333); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.ajax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/device/index.blade.php ENDPATH**/ ?>
<?php $__env->startComponent('admin._components.general-input'); ?>
    <?php $__env->slot('field', 'title'); ?>
    <?php $__env->slot('label', 'Title / Judul'); ?>
    <?php $__env->slot('placeholder', 'Masukkan nama judul'); ?>
    <?php $__env->slot('required', true); ?>
<?php if (isset($__componentOriginal80d5de7339a6849abefba7946dc98a501a027bf5)): ?>
<?php $component = $__componentOriginal80d5de7339a6849abefba7946dc98a501a027bf5; ?>
<?php unset($__componentOriginal80d5de7339a6849abefba7946dc98a501a027bf5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('admin._components.general-input'); ?>
    <?php $__env->slot('field', 'file'); ?>
    <?php $__env->slot('type', 'file'); ?>
    <?php $__env->slot('label', 'File'); ?>
    <?php $__env->slot('placeholder', 'Choose File'); ?>
    <?php $__env->slot('required', true); ?>
<?php if (isset($__componentOriginal80d5de7339a6849abefba7946dc98a501a027bf5)): ?>
<?php $component = $__componentOriginal80d5de7339a6849abefba7946dc98a501a027bf5; ?>
<?php unset($__componentOriginal80d5de7339a6849abefba7946dc98a501a027bf5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('admin._components.general-textarea'); ?>
    <?php $__env->slot('field', 'description'); ?>
    <?php $__env->slot('label', 'Deskripsi'); ?>
<?php if (isset($__componentOriginal58e444c2479615ee48dac35d5f55c3206759de03)): ?>
<?php $component = $__componentOriginal58e444c2479615ee48dac35d5f55c3206759de03; ?>
<?php unset($__componentOriginal58e444c2479615ee48dac35d5f55c3206759de03); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/guide/_partials/form.blade.php ENDPATH**/ ?>
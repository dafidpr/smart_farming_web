
<?php $__env->startSection('content'); ?>

<div class="nk-content-body">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><?php echo e($title); ?></h3>
                <div class="nk-block-des text-soft">
                    <p>You have total <?php echo e($farmers->count()); ?>  petani.</p>
                </div>
            </div><!-- .nk-block-head-content -->
            <div class="nk-block-head-content">
                <div class="toggle-wrap nk-block-tools-toggle">
                    <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                    <div class="toggle-expand-content" data-content="pageMenu">
                        <ul class="nk-block-tools g-3">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-farmers')): ?>
                                <li><a href="/administrator/farmers/create" class="ajaxAction btn btn-light bg-white"><em class="icon ni ni-plus"></em><span>Tambah  Petani</span></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div><!-- .toggle-wrap -->
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->
    <div class="nk-block">
        <div class="card card-bordered card-preview">
            <div class="card-inner-group">
                <ul class="nav nav-tabs nav-tabs-mb-icon nav-tabs-card">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#tabGeneral"><em class="icon ni ni-db"></em><span> Semua Petani</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabImage"><em class="icon ni ni-layout"></em><span> Permintaan Registrasi</span></a>
                        <?php if($farmerPending->count() > 0): ?>
                            <div class="dot dot-primary" style="margin-bottom:10px"></div>
                        <?php endif; ?>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabConfig"><em class="icon ni ni-trash"></em><span> Trash</span></a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="tabGeneral">
                        <div class="card-inner p-4">
                            <div class="nk-block">
                                <div class="nk-block-head" style="margin-top:-15px">
                                    <h5 class="title">Semua Data Petani</h5>
                                    <p>Semua data petani yang petani ada pada halaman ini.</p>
                                </div><!-- .nk-block-head -->
                                <div class="card-inner-group">
                                    
                                    <div class="card-inner p-4">
                                        <table class="datatable-init nk-tb-list nk-tb-ulist" data-auto-responsive="false" id="">
                                            <thead class="nk-tb-head bg-light-table">
                                                <tr class="nk-tb-item">
                                                    
                                                    <th class="nk-tb-col"><span class="sub-text">Nama Petani</span></th>
                                                    <th class="nk-tb-col tb-col-mb"><span class="sub-text">Kelompok Tani</span></th>
                                                    <th class="nk-tb-col tb-col-mb"><span class="sub-text">Nomor Telp</span></th>
                                                    <th class="nk-tb-col tb-col-md"><span class="sub-text">Email</span></th>
                                                    <th class="nk-tb-col tb-col-md"><span class="sub-text">Luas Lahan</span></th>
                                                    <th class="nk-tb-col tb-col-lg"><span class="sub-text">Status</span></th>
                                                    <th class="nk-tb-col nk-tb-col-tools text-right"></th>
                                                </tr>
                                            </thead><!-- .nk-tb-item -->
                                            <tbody>
                                                <?php $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                    <tr class="nk-tb-item">
                                                        
                                                        <td class="nk-tb-col">
                                                            <div>
                                                                <div class="user-card">
                                                                    <div class="user-info">
                                                                        <span class="tb-lead"><?php echo e($item->name); ?></span>
                                                                        <ul class="list-status">
                                                                            <li><em class="icon ni ni-alert-circle"></em> <span>Serial Number : <?php echo e($item->serial_number); ?></span></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-mb">
                                                            <span><?php echo e($item->farmerGroup->name); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-mb">
                                                            <span><?php echo e($item->phone); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-md">
                                                            <span><?php echo e($item->email); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-md">
                                                            <span><?php echo e($item->land_area); ?> M2</span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-lg">
                                                            <span class="badge badge-dot badge-<?php echo e($item->block == 'Y' ? 'danger' : 'success'); ?>"><?php echo e($item->block == 'Y' ? 'Terblokir' : 'Aktif'); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col nk-tb-col-tools">
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update-farmers','delete-farmers'])): ?>
                                                                <ul class="nk-tb-actions gx-1">
                                                                    <li>
                                                                        <div class="drodown">
                                                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                <ul class="link-list-opt no-bdr">
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-farmers')): ?>
                                                                                        <li><a href="/administrator/farmers/<?php echo e(Hashids::encode($item->id)); ?>/edit" class="ajaxAction"><em class="icon ni ni-edit"></em><span>Edit  Petani</span></a></li> 
                                                                                    <?php endif; ?>
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-farmers')): ?>
                                                                                        <li><a class="deleteItem" href="/administrator/farmers/<?php echo e(Hashids::encode($item->id)); ?>/delete"><em class="icon ni ni-trash"></em><span>Delete  Petani</span></a></li>
                                                                                    <?php endif; ?>
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-farmers')): ?>     
                                                                                        <li class="divider"></li>
                                                                                        <li><a href="#" class="block-farmer" data-id="<?php echo e(Hashids::encode($item->id)); ?>"><em class="<?php echo e($item->block == 'N' ? 'icon ni ni-na' : 'icon ni ni-unlock'); ?>"></em><span><?php echo e($item->block == 'N' ? 'Block Petani' : 'Unblock Petani'); ?></span></a></li>
                                                                                    <?php endif; ?>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr><!-- .nk-tb-item -->
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table><!-- .nk-tb-list -->
                                    </div><!-- .card-inner -->
                                </div><!-- .card-inner-group -->
                            </div>
                        </div><!-- .card-inner -->
                    </div>
                    <div class="tab-pane" id="tabImage">
                        <div class="card-inner p-4">
                            <div class="nk-block">
                                <div class="nk-block-head" style="margin-top:-15px">
                                    <h5 class="title">Permintaan Registrasi</h5>
                                    <p>Semua permintaan registrasi petani ada pada halaman ini.</p>
                                </div><!-- .nk-block-head -->
                                <div class="card-inner-group">
                                    
                                    <div class="card-inner p-4">
                                        <table class="datatable-init nk-tb-list nk-tb-ulist" data-auto-responsive="false" id="">
                                            <thead class="nk-tb-head bg-light-table">
                                                <tr class="nk-tb-item">
                                                    
                                                    <th class="nk-tb-col"><span class="sub-text">Nama Kelompok Tani</span></th>
                                                    <th class="nk-tb-col tb-col-mb"><span class="sub-text">Kelompok Tani</span></th>
                                                    <th class="nk-tb-col tb-col-mb"><span class="sub-text">Nomor Telp</span></th>
                                                    <th class="nk-tb-col tb-col-md"><span class="sub-text">Email</span></th>
                                                    <th class="nk-tb-col tb-col-md"><span class="sub-text">Luas Lahan</span></th>
                                                    <th class="nk-tb-col tb-col-lg"><span class="sub-text">Status</span></th>
                                                    <th class="nk-tb-col nk-tb-col-tools text-right"></th>
                                                </tr>
                                            </thead><!-- .nk-tb-item -->
                                            <tbody>
                                                <?php $__currentLoopData = $farmerPending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                    <tr class="nk-tb-item">
                                                        
                                                        <td class="nk-tb-col">
                                                            <div>
                                                                <div class="user-card">
                                                                    <div class="user-info">
                                                                        <span class="tb-lead"><?php echo e($item->name); ?></span>
                                                                        <ul class="list-status">
                                                                            <li><em class="icon ni ni-alert-circle"></em> <span>Serial Number : <?php echo e($item->serial_number); ?></span></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-mb">
                                                            <span><?php echo e($item->farmerGroup->name); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-mb">
                                                            <span><?php echo e($item->phone); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-md">
                                                            <span><?php echo e($item->email); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-md">
                                                            <span><?php echo e($item->land_area); ?> M2</span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-lg">
                                                            <span class="badge badge-dot badge-warning">Pending</span>
                                                        </td>
                                                        <td class="nk-tb-col nk-tb-col-tools">
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update-farmers'])): ?>
                                                                <ul class="nk-tb-actions gx-1">
                                                                    <li>
                                                                        <div class="drodown">
                                                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                <ul class="link-list-opt no-bdr">
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-farmers')): ?>
                                                                                        <li><a data-url="/administrator/farmers/<?php echo e(Hashids::encode($item->id)); ?>/approve" href="#" data-action="approve" class="change-status"><em class="icon ni ni-check-c"></em><span>Approve  Petani</span></a></li> 
                                                                                    <?php endif; ?>
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-farmers')): ?>
                                                                                        <li><a class="change-status" href="#" data-action="reject" data-url="/administrator/farmers/<?php echo e(Hashids::encode($item->id)); ?>/reject"><em class="icon ni ni-cross-c"></em><span>Reject  Petani</span></a></li>
                                                                                    <?php endif; ?>
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-farmers')): ?>
                                                                                        <li><a class="deleteItem" href="/administrator/farmers/<?php echo e(Hashids::encode($item->id)); ?>/delete"><em class="icon ni ni-trash"></em><span>Delete  Petani</span></a></li>
                                                                                    <?php endif; ?>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr><!-- .nk-tb-item -->
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table><!-- .nk-tb-list -->
                                    </div><!-- .card-inner -->
                                </div><!-- .card-inner-group -->
                            </div>
                              
                        </div><!-- .card-inner -->
                    </div>
                    <div class="tab-pane" id="tabConfig">
                        <div class="card-inner p-4">
                            <div class="nk-block">
                                <div class="nk-block-head" style="margin-top:-15px">
                                    <h5 class="title">Trash</h5>
                                    <p>Semua petani yang registrasinya di tolak ada di sini.</p>
                                </div><!-- .nk-block-head -->
                                <div class="card-inner-group">
                                    
                                    <div class="card-inner p-4">
                                        <table class="datatable-init nk-tb-list nk-tb-ulist" data-auto-responsive="false" id="">
                                            <thead class="nk-tb-head bg-light-table">
                                                <tr class="nk-tb-item">
                                                    
                                                    <th class="nk-tb-col"><span class="sub-text">Nama Kelompok Tani</span></th>
                                                    <th class="nk-tb-col tb-col-mb"><span class="sub-text">Kelompok Tani</span></th>
                                                    <th class="nk-tb-col tb-col-mb"><span class="sub-text">Nomor Telp</span></th>
                                                    <th class="nk-tb-col tb-col-md"><span class="sub-text">Email</span></th>
                                                    <th class="nk-tb-col tb-col-md"><span class="sub-text">Luas Lahan</span></th>
                                                    <th class="nk-tb-col tb-col-lg"><span class="sub-text">Status</span></th>
                                                    <th class="nk-tb-col nk-tb-col-tools text-right"></th>
                                                </tr>
                                            </thead><!-- .nk-tb-item -->
                                            <tbody>
                                                <?php $__currentLoopData = $farmerReject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                    <tr class="nk-tb-item">
                                                        
                                                        <td class="nk-tb-col">
                                                            <div>
                                                                <div class="user-card">
                                                                    <div class="user-info">
                                                                        <span class="tb-lead"><?php echo e($item->name); ?></span>
                                                                        <ul class="list-status">
                                                                            <li><em class="icon ni ni-alert-circle"></em> <span>Serial Number : <?php echo e($item->serial_number); ?></span></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-mb">
                                                            <span><?php echo e($item->farmerGroup->name); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-mb">
                                                            <span><?php echo e($item->phone); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-md">
                                                            <span><?php echo e($item->email); ?></span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-md">
                                                            <span><?php echo e($item->land_area); ?> M2</span>
                                                        </td>
                                                        <td class="nk-tb-col tb-col-lg">
                                                            <span class="badge badge-dot badge-danger">Rejected</span>
                                                        </td>
                                                        <td class="nk-tb-col nk-tb-col-tools">
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['delete-farmers'])): ?>
                                                                <ul class="nk-tb-actions gx-1">
                                                                    <li>
                                                                        <div class="drodown">
                                                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                                <ul class="link-list-opt no-bdr">
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-farmers')): ?>
                                                                                        <li><a class="deleteItem" href="/administrator/farmers/<?php echo e(Hashids::encode($item->id)); ?>/delete"><em class="icon ni ni-trash"></em><span>Delete  Petani</span></a></li>
                                                                                    <?php endif; ?>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr><!-- .nk-tb-item -->
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table><!-- .nk-tb-list -->
                                    </div><!-- .card-inner -->
                                </div><!-- .card-inner-group -->
                            </div>
                        </div><!-- .card-inner -->
                    </div>
                </div>
            </div><!-- .card-inner-group -->
        </div><!-- .card -->
    </div><!-- .nk-block -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.ajax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/farmer/index.blade.php ENDPATH**/ ?>
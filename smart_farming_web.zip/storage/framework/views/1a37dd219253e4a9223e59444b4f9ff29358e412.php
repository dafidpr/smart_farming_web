
<?php $__env->startSection('content'); ?>

<div class="nk-content-body">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><?php echo e($title); ?></h3>
            </div><!-- .nk-block-head-content -->
            <div class="nk-block-head-content">
                <div class="toggle-wrap nk-block-tools-toggle">
                    <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                    <div class="toggle-expand-content" data-content="pageMenu">
                        <ul class="nk-block-tools g-3">
                            <li><a href="/administrator/farmers" class="ajaxAction btn btn-light bg-white"><em class="icon ni ni-arrow-left"></em><span> Back</span></a></li>
                        </ul>
                    </div>
                </div><!-- .toggle-wrap -->
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->
    <div class="nk-block">
        <div class="card card-bordered card-stretch">
            <div class="card-inner">
                <div class="preview-block">
                    <form action="<?php echo e($action); ?>" method="post" enctype="multipart/form-data" id="formSubmit">
                        <div class="row gy-4">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="form-label" for="default-01">Nama Lengkap <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Nama Lengkap" autocomplete="off" value="<?php echo e(isset($farmer->name) ? $farmer->name : ''); ?>">
                                        <i class="text-danger small d-none" id="nameErr"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="form-label" for="default-01">Username <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" <?php echo e(isset($farmer->username) ? 'readonly' : ''); ?> autocomplete="off" value="<?php echo e(isset($farmer->username) ? $farmer->username : ''); ?>">
                                        <i class="text-danger small d-none" id="usernameErr"></i>
                                    </div>
                                </div>
                            </div>
                        
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="form-label" for="default-03">Email <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left">
                                            <em class="icon ni ni-mail"></em>
                                        </div>
                                        <input type="text" class="form-control" id="email" name="email" placeholder="Email" autocomplete="off" value="<?php echo e(isset($farmer->email) ? $farmer->email : ''); ?>">
                                    </div>
                                    <i class="text-danger small d-none" id="emailErr"></i>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="form-label" for="default-03">Password <span class="text-danger"><?php echo e(isset($farmer->password) ? '' : '*'); ?></span></label>
                                    <div class="form-control-wrap">
                                        <a href="#" class="form-icon form-icon-right passcode-switch show-password" data-target="password">
                                            <em class="passcode-icon icon-show icon ni ni-eye"></em>
                                            <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                                        </a>
                                        <input type="password" class="form-control" name="password" id="password" placeholder="Password" autocomplete="off" <?php echo e(isset($farmer->password) ? 'disabled' : ''); ?>>
                                    </div>
                                    <i class="text-danger small d-none" id="passwordErr"></i>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="form-label" for="default-01">Tempat lahir</label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control" id="birthplace" name="birthplace" placeholder="Tempat Lahir" autocomplete="off" value="<?php echo e(isset($farmer->birthplace) ? $farmer->birthplace : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label class="form-label" for="default-01">Tanggal lahir</label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control date-picker" id="birthday" name="birthday" placeholder="Tanggal Lahir" autocomplete="off" value="<?php echo e(isset($farmer->birthday) ? $farmer->birthday : ''); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <select class="form-select form-control form-control-lg" name="gender">
                                            <?php if(isset($farmer->gender)): ?>
                                                <option value="male" <?php echo e($farmer->gender == 'male' ? 'selected' : ''); ?>>Laki-Laki</option>
                                                <option value="female" <?php echo e($farmer->gender == 'female' ? 'selected' : ''); ?>>Perempuan</option>
                                            <?php else: ?>
                                                <option value="male">Laki-Laki</option>
                                                <option value="female">Perempuan</option>
                                            <?php endif; ?>
                                            </select>
                                        <i class="text-danger small d-none" id="genderErr"></i>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="form-label" for="default-01">Nomor Telepon <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone Number" autocomplete="off" value="<?php echo e(isset($farmer->phone) ? $farmer->phone : ''); ?>">
                                        <i class="text-danger small d-none" id="phoneErr"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="form-label">Block <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <select class="form-select form-control form-control-lg" name="block">
                                            <?php if(isset($farmer->block)): ?>
                                                <option value="N" <?php echo e($farmer->block == 'N' ? 'selected' : ''); ?>>Unblock</option>
                                                <option value="Y" <?php echo e($farmer->block == 'Y' ? 'selected' : ''); ?>>Block</option>
                                            <?php else: ?>
                                                <option value="N">Unblock</option>
                                                <option value="Y">Block</option>
                                            <?php endif; ?>
                                            </select>
                                        <i class="text-danger small d-none" id="blockErr"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="form-label" for="default-01">Serial Number <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control" id="serial_number" name="serial_number" placeholder="Serial Number" autocomplete="off" value="<?php echo e(isset($farmer->serial_number) ? $farmer->serial_number : ''); ?>">
                                        <i class="text-danger small d-none" id="serialNumberErr"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="form-label" for="default-01">Luas Lahan <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <input type="number" class="form-control" id="land_area" name="land_area" placeholder="Luas Lahan" autocomplete="off" value="<?php echo e(isset($farmer->land_area) ? $farmer->land_area : ''); ?>">
                                        <i class="text-danger small d-none" id="landAreaErr"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="form-label">Kelompok Tani <span class="text-danger">*</span></label>
                                    <div class="form-control-wrap">
                                        <select class="form-select form-control form-control-lg" name="farmer_group_id" data-search="on">
                                            <?php $__currentLoopData = $farmerGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($farmer->farmer_group_id)): ?>
                                                    <?php if($farmer->farmer_group_id == $item->id): ?>
                                                        <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->name); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <i class="text-danger small d-none" id="farmerGroupErr"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="form-label" for="default-01">Alamat</label>
                                    <div class="form-control-wrap">
                                        <textarea name="address" id="address" cols="30" rows="1" class="form-control"><?php echo e(isset($farmer->address) ? $farmer->address : ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                          
                        </div>
                        <hr class="preview-hr">
                        <button type="submit" class="btn btn-primary"><em class="icon ni ni-send"></em><span> Save changes </span> </button>
                    </form>
                </div>
            </div>
        </div><!-- .card -->
    </div><!-- .nk-block -->
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.ajax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/farmer/form.blade.php ENDPATH**/ ?>
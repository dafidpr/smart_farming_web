<div class="form-group">
    <?php if(isset($label)): ?>
        <label class="form-label" for="<?php echo e($field ?? $id); ?>"><?php echo e($label); ?> <?php if(isset($required) && $required): ?> <span class="text-danger">*</span> <?php endif; ?></label>
    <?php endif; ?>
    <div class="form-control-wrap">
        <textarea name="<?php echo e($field); ?>" cols="<?php echo e($cols ?? 30); ?>" rows="<?php echo e($rows ?? 1); ?>" id="<?php echo e($field ?? $id); ?>" class="form-control <?php echo e($classes ?? ''); ?>"><?php echo e(isset($lecturer->address) ? $lecturer->address : ''); ?></textarea>
    </div>
    <i class="text-danger small d-none" id="<?php echo e($field); ?>-error"></i>
</div>
<?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/_components/general-textarea.blade.php ENDPATH**/ ?>
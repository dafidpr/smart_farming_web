<?php $__env->startComponent('admin._components.general-input'); ?>
    <?php $__env->slot('field', 'role'); ?>
    <?php $__env->slot('label', 'Nama Role'); ?>
    <?php $__env->slot('required', true); ?>
    <?php $__env->slot('placeholder', 'Masukkan nama role'); ?>
<?php if (isset($__componentOriginal80d5de7339a6849abefba7946dc98a501a027bf5)): ?>
<?php $component = $__componentOriginal80d5de7339a6849abefba7946dc98a501a027bf5; ?>
<?php unset($__componentOriginal80d5de7339a6849abefba7946dc98a501a027bf5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Project Apps\Laravel Apps\smart_farming_web\resources\views/admin/role/_partials/form.blade.php ENDPATH**/ ?>
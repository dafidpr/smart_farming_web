var displayErrors = [
    {
        display: '#nameErr',
        inputName: 'name'
    },
    {
        display: '#chairmanErr',
        inputName: 'chairman'
    },
    {
        display: '#yearErr',
        inputName: 'year'
    },
    {
        display: '#addressErr',
        inputName: 'address'
    },
    {
        display: '#latitudeErr',
        inputName: 'latitude'
    },

    {
        display: '#longitudeErr',
        inputName: 'longitude'
    }
];

